﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInspection.Classes
{
    public class TempUser : INotifyPropertyChanged
    {
        private string _paramter;
        public string Paramter
        {
            get { return _paramter; }
            set
            {
                _paramter = value;
                OnPropertyChanged("Paramter");
            }
        }

       

        private string _value;
        public string Value
        {
            get { return _value; }
            set
            {
                _value = value;
                OnPropertyChanged("Value");
            }
        }

      



        public TempUser(string paramter,  string value)
        {
            Paramter = paramter;
           
            Value = value;
           
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
