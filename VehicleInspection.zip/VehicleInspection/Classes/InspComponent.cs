﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInspection.Classes
{
   public class InspComponent : INotifyPropertyChanged
    {

        private string _componentname;
        public string Componentname
        {
            get { return _componentname; }
            set
            {
                _componentname = value;
                OnPropertyChanged("Componentname");
            }
        }

        private string _chkfitment;
        public string Chkfitment
        {
            get { return _chkfitment; }
            set
            {
                _chkfitment = value;
                OnPropertyChanged("Chkfitment");
            }
        }

        private string _chkmaketyperating;
        public string Chkmaketyperating
        {
            get { return _chkmaketyperating; }
            set
            {
                _chkmaketyperating = value;
                OnPropertyChanged("Chkmaketyperating");
            }
        }


        private string _chkconditions;
        public string ChkConditions
        {
            get { return _chkconditions; }
            set
            {
                _chkconditions = value;
                OnPropertyChanged("ChkConditions");
            }
        }


        private string _chkfunctioning;
        public string Chkfunctioning
        {
            get { return _chkfunctioning; }
            set
            {
                _chkfunctioning = value;
                OnPropertyChanged("Chkfunctioning");
            }
        }

        private string _test;
        public string Test
        {
            get { return _test; }
            set
            {
                _test = value;
                OnPropertyChanged("Test");
            }
        }

        private string _Remark;
        public string Remark
        {
            get { return _Remark; }
            set
            {
                _Remark = value;
                OnPropertyChanged("Remark");
            }
        }

        public InspComponent(string compname, string chkfitment,string chkmaketype,string condi,string function,string test,string remark)
        {
            Componentname = compname;
            Chkfitment = chkfitment;
            Chkmaketyperating = chkmaketype;
            ChkConditions = condi;
            Chkfunctioning = function;
            Test = test;
            Remark = remark;

        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
