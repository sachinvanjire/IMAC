﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VehicleInspection.View
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Frame _frmmain = new Frame();
        public Login()
        {
            InitializeComponent();

            _frmmain = (Frame)System.Windows.Application.Current.MainWindow.FindName("frmmain");
            cmbrole.Items.Add("Inspector");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
     



            if (!string.IsNullOrEmpty(txtusername.Text))
            {
                if (!string.IsNullOrEmpty(txtpassword.Password))
                {


                }
                else
                {
                    MessageBox.Show("Password required");
                    return;
                }

            }
            else
            {
                MessageBox.Show("Username required");
                return;
            }


            if ("Admin" == txtusername.Text)
            {
                if ("1" == txtpassword.Password)
                {
                    _frmmain.Navigate(new Master());
                }
            }
          
         
       
        
            //clsGlobal.GlobalUser = txtusername.Text;
            txtusername.Text = "";
            txtpassword.Password = "";
        }
    }
}
