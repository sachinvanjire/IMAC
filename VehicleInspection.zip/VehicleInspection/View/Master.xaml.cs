﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VehicleInspection.Classes;

namespace VehicleInspection.View
{
    /// <summary>
    /// Interaction logic for Master.xaml
    /// </summary>
    public partial class Master : Page, INotifyPropertyChanged
    {
        private ObservableCollection<TempUser> _ReadUSER;
        public ObservableCollection<TempUser> ReadUSER
        {
            get
            {
                return _ReadUSER;
            }
            set
            {
                _ReadUSER = value;
                OnPropertyChanged("ReadUSER");
            }
        }

        private ObservableCollection<TempUser> _ReadUSERinfo;
        public ObservableCollection<TempUser> ReadUSERInfo
        {
            get
            {
                return _ReadUSERinfo;
            }
            set
            {
                _ReadUSERinfo = value;
                OnPropertyChanged("ReadUSERInfo");
            }
        }

        private ObservableCollection<InspComponent> _ReadComponent;
        public ObservableCollection<InspComponent> ReadComponent
        {
            get
            {
                return _ReadComponent;
            }
            set
            {
                _ReadComponent = value;
                OnPropertyChanged("ReadComponent");
            }
        }

      

        public Master()
        {
            InitializeComponent();

            ReadComponent = new ObservableCollection<InspComponent>();

            cmbBody.Items.Add("Passanger");
            cmbBody.Items.Add("commercial");
            cmbBody.Items.Add("Electrical");
            cmbBody.Items.Add("Hybrid");

            cmbcolor.Items.Add("White");
            cmbcolor.Items.Add("Red");
            cmbcolor.Items.Add("Blue");
            cmbcolor.Items.Add("Green");

            cmbComponent.Items.Add("SparkPlugSupressHighTention");
            cmbComponent.Items.Add("HeadLampBeams");
            cmbComponent.Items.Add("Other lights");
            cmbComponent.Items.Add("Reflectors");
            cmbComponent.Items.Add("Bulbs");
            cmbComponent.Items.Add("RearViewMirror");
            cmbComponent.Items.Add("SaftyGlass");
            cmbComponent.Items.Add("Horn");
            cmbComponent.Items.Add("Silenser");
            cmbComponent.Items.Add("Dashboard Equipement");
            cmbComponent.Items.Add("Windshield wiper");
            cmbComponent.Items.Add("Exhuast Emission");
            cmbComponent.Items.Add("Breaking system");
            cmbComponent.Items.Add("Speedo Meter");
            cmbComponent.Items.Add("Steering Gear");
            cmbComponent.Items.Add("Rear Underrun protecting device");
            cmbComponent.Items.Add("Lateral side protection device");
            cmbComponent.Items.Add("Priority seat signs");
            cmbComponent.Items.Add("Wheel chair entry");
            cmbComponent.Items.Add("Maximum Speed");
            cmbComponent.Items.Add("Reflectors");

            cmbMakeTypeRating.Items.Add("Yes");
            cmbMakeTypeRating.Items.Add("No");

            cmbFitment.Items.Add("Yes");
            cmbFitment.Items.Add("No");

            cmbConditions.Items.Add("Yes");
            cmbConditions.Items.Add("No");

            cmbFunctioning.Items.Add("Yes");
            cmbFunctioning.Items.Add("No");

            cmbTest.Items.Add("Yes");
            cmbTest.Items.Add("No");

            var listuser = new ObservableCollection<TempUser>();
            listuser.Add(new TempUser("Inspector Name", "Mr.Shardul Patil"));
            listuser.Add(new TempUser("Employee ID", "3526l"));
            listuser.Add(new TempUser("Job Title", "Vehicle Inspector"));
            listuser.Add(new TempUser("Work Place", "Pune District Office"));
            listuser.Add(new TempUser("Address", "District office,Near shivaji chowk,Pune Maharashtra"));
            ReadUSERInfo = new ObservableCollection<TempUser>(listuser);
            this.DataContext = this;
        }

        private void cmbstation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

           if(cmbBody.Text!= "Electrical")
            {
                gridpuc.Visibility = Visibility.Visible;
            }
            else 
            {
                gridpuc.Visibility = Visibility.Hidden;
            }

            

        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            dgRead.Visibility = Visibility.Visible;

            var originalList = new ObservableCollection<TempUser>();
            originalList.Add(new TempUser("Vehicle Registration Number", txtvehreg.Text));
            originalList.Add(new TempUser("Vehicle Color", cmbcolor.Text));
            originalList.Add(new TempUser("Vehicle Chasis Number", txtchasis.Text));
            originalList.Add(new TempUser("Vehicle Engine Number", txtveheng.Text));
            originalList.Add(new TempUser("Vehicle Body Type", cmbBody.Text));
            originalList.Add(new TempUser("Vehicle Manufacturing date", DateTimePicker1.Text));
            originalList.Add(new TempUser("PUC Details", txtPUC.Text));
            originalList.Add(new TempUser("SLD Details", txtSLD.Text));
            ReadUSER = new ObservableCollection<TempUser>(originalList);
        }


        private void ButtonComponent_Click(object sender, RoutedEventArgs e)
        {



            ReadComponent.Add(new InspComponent(cmbComponent.Text,cmbFitment.Text,cmbMakeTypeRating.Text,cmbConditions.Text,cmbFunctioning.Text,cmbTest.Text,txtRemarkcomponent.Text));
           
        
           
        }

        private void ButtonOpenPath_Click(object sender, RoutedEventArgs e)
        {



            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();

           Nullable<bool> result = openFileDlg.ShowDialog();
         
            if (result == true)
            {
                
                txtPath.Text = openFileDlg.FileName;
                
            }



        }


        private void ButtonUpload_Click(object sender, RoutedEventArgs e)
        {




            MessageBox.Show("File Uploaded Successfully");
            txtPath.Text = "";



        }

        private void ButtonManufacturingData_Click(object sender, RoutedEventArgs e)
        {
            lstfaults.Items.Add("Connecting and Retriving data from server.....");
            lstVehinfo.Items.Add("Connecting and Retriving data from server.....");

            System.Threading.Thread.Sleep(4000);
            lstfaults.Items.Clear();
            lstVehinfo.Items.Clear();

            lstfaults.Items.Add("Battery voltage too low-Active");
            lstfaults.Items.Add("Vehicle speed Sensor error-Active");
            lstfaults.Items.Add("MIL lamp is not working correctly-Active");
            lstfaults.Items.Add("Tire pressure too low-Inactive");

            lstVehinfo.Items.Add("Kilometer run counter - 33000");
            lstVehinfo.Items.Add("Vehicle Engine number - gdhfkl28823");
            lstVehinfo.Items.Add("Vehicle Manufacturing data - 20-10-2016");
            lstVehinfo.Items.Add("Vehicle type - Commercial");




        }

        private void ButtonInspect_Click(object sender, RoutedEventArgs e)
        {


            MessageBox.Show("Inspection done.Windshield found defective");


        }
    }

}

internal class TempUSERS : TempUser
    {
        public TempUSERS(string paramter, string value) : base(paramter, value)
        {
        }
    }

